java -cp osrmt-1.8-SNAPSHOT.jar:libs/* com.osrmt.appclient.reqmanager.RequirementManagerController
